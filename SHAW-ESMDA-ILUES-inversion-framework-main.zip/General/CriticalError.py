class CriticalError(Exception):
    pass